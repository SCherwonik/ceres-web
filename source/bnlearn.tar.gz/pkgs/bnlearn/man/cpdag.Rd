\name{cpdag}
\alias{cpdag}
\alias{cextend}
\alias{cextend.all}
\alias{moral}
\alias{colliders}
\alias{shielded.colliders}
\alias{unshielded.colliders}
\alias{vstructs}
\title{Equivalence classes, moral graphs and consistent extensions}
\description{

  Find the equivalence class and the v-structures of a Bayesian network,
  construct its moral graph, or create a consistent extension of an equivalent
  class.

}
\usage{
cpdag(x, wlbl = FALSE, debug = FALSE)
cextend(x, strict = TRUE, debug = FALSE)
moral(x, debug = FALSE)

cextend.all(x, debug = FALSE)

colliders(x, arcs = FALSE, debug = FALSE)
shielded.colliders(x, arcs = FALSE, debug = FALSE)
unshielded.colliders(x, arcs = FALSE, debug = FALSE)
vstructs(x, arcs = FALSE, debug = FALSE)
}
\arguments{
  \item{x}{an object of class \code{bn} or \code{bn.fit} (with the exception of
    \code{cextend()}, which only accepts objects of class \code{bn}).}
  \item{arcs}{a boolean value. If \code{TRUE}, the arcs that are part of at
    least one v-structure are returned instead of the v-structures themselves.}
  \item{wlbl}{a boolean value. If \code{TRUE}, arcs whose directions have been
    fixed by a whitelist or a blacklist are preserved when constructing the
    CPDAG.}
  \item{strict}{a boolean value. If no consistent extension is possible and
    \code{strict} is \code{TRUE}, an error is generated. Otherwise, a partially
    extended graph is returned with a warning.}
  \item{debug}{a boolean value. If \code{TRUE}, a lot of debugging output is
    printed. Otherwise, the function is completely silent.}
}
\details{

  Note that arcs whose directions are dictated by the parametric assumptions of
  the network are preserved as directed arcs in \code{cpdag()}. This means that,
  in a conditional Gaussian network, arcs from discrete nodes to continuous
  nodes will be treated as whitelisted in their only valid direction.

  \code{cextend.all()} returns all possible consistent extensions of a CPDAG,
  whereas \code{cextend()} returns only one. \code{cextend.all()} also accepts a
  PDAG or an MPDAG (a partially directed graph carrying background knowledge, in
  which some directed arcs are not compelled), in which case it enumerates the
  consistent extensions that agree with the given arc directions; it stops with
  an error if no such extension exists.

}
\value{

  \code{cpdag()} returns an object of class \code{bn}, representing the
  equivalence class. \code{moral} on the other hand returns the moral graph.
  See \code{\link{bn-class}} for details.

  \code{cextend()} returns an object of class \code{bn}, representing a DAG that
  is the consistent extension of \code{x}.

  \code{cextend.all()} returns an object of class \code{bn} or a list of objects
  of class \code{bn}.

  \code{vstructs()}, \code{colliders()}, \code{shielded.colliders()} and
  \code{unshielded.colliders()} return a matrix with either 2 or 3 columns,
  according to the value of the \code{arcs} argument.

}
\references{

  Dor D (1992). \emph{A Simple Algorithm to Construct a Consistent Extension of
    a Partially Oriented Graph}. UCLA, Cognitive Systems Laboratory.

  Koller D, Friedman N (2009). \emph{Probabilistic Graphical Models: Principles
    and Techniques}. MIT Press.

  Pearl J (2009). \emph{Causality: Models, Reasoning and Inference}. Cambridge
    University Press, 2nd edition.

  Andersson SA, Madigan D, Perlman MD (1997). "A Characterization of Markov
    Equivalence Classes for Acyclic Digraphs." \emph{The Annals of Statistics},
    \strong{25}(2):505--541.

  Wienobst M, Luttermann M, Bannach M, Liskiewicz M (2023). "Efficient
    Enumeration of Markov Equivalent DAGs." \emph{Proceedings of the
    Thirty-Seventh AAAI Conference on Artificial Intelligence}, 12313--12320.

}
\examples{
data(learning.test)
dag = hc(learning.test)
cpdag(dag)
vstructs(dag)
}
\author{Marco Scutari}
\keyword{graphs}
\keyword{structure learning}
