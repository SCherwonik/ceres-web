\name{learning.test}
\docType{data}
\alias{learning.test}
\title{Synthetic (discrete) data set to test learning algorithms}
\description{

  This is a synthetic data set used as a test case in the \pkg{bnlearn} package.

}
\usage{
data(learning.test)
}
\format{

  The \code{learning.test} data set contains the following variables:
  \itemize{

    \item \code{A}, a three-level factor with levels \code{a}, \code{b} and
      \code{c}.
    \item \code{B}, a three-level factor with levels \code{a}, \code{b} and
      \code{c}.
    \item \code{C}, a three-level factor with levels \code{a}, \code{b} and
      \code{c}.
    \item \code{D}, a three-level factor with levels \code{a}, \code{b} and
      \code{c}.
    \item \code{E}, a three-level factor with levels \code{a}, \code{b} and
      \code{c}.
    \item \code{F}, a two-level factor with levels \code{a} and \code{b}.

  }

}
\note{

  The R script to generate data from this network is available from
  \url{https://www.bnlearn.com/documentation/networks/}.

}
\examples{
# load the data.
data(learning.test)
# create and plot the network structure.
dag = model2network("[A][C][F][B|A][D|A:C][E|B:F]")
\dontrun{graphviz.plot(dag)}
}
\keyword{datasets}
