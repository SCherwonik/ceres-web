#include "../include/rcore.h"
#include "scores.h"

#define ENTRY(key, value) \
  do { \
    if (strcmp(label, key) == 0) return value; \
  } while (0)

score_e score_to_enum(const char *label) {

  ENTRY("loglik", LOGLIK);
  ENTRY("aic", AIC);
  ENTRY("bic", BIC);
  ENTRY("ebic", EBIC);
  ENTRY("bde", BDE);
  ENTRY("bds", BDS);
  ENTRY("bdj", BDJ);
  ENTRY("k2", K2);
  ENTRY("mbde", MBDE);
  ENTRY("pred-loglik", PRED_LOGLIK);
  ENTRY("fnml", FNML);
  ENTRY("qnml", QNML);
  ENTRY("nal", NAL);
  ENTRY("pnal", PNAL);
  ENTRY("loglik-g", LOGLIK_G);
  ENTRY("aic-g", AIC_G);
  ENTRY("bic-g", BIC_G);
  ENTRY("ebic-g", EBIC_G);
  ENTRY("bge", BGE);
  ENTRY("pred-loglik-g", PRED_LOGLIK_G);
  ENTRY("nal-g", NAL_G);
  ENTRY("pnal-g", PNAL_G);
  ENTRY("loglik-cg", LOGLIK_CG);
  ENTRY("aic-cg", AIC_CG);
  ENTRY("bic-cg", BIC_CG);
  ENTRY("ebic-cg", EBIC_CG);
  ENTRY("pred-loglik-cg", PRED_LOGLIK_CG);
  ENTRY("nal-cg", NAL_CG);
  ENTRY("pnal-cg", PNAL_CG);
  ENTRY("loglik-zihp", LOGLIK_ZIHP);
  ENTRY("loglik-zinb", LOGLIK_ZINB);
  ENTRY("aic-zihp", AIC_ZIHP);
  ENTRY("bic-zihp", BIC_ZIHP);
  ENTRY("aic-zinb", AIC_ZINB);
  ENTRY("bic-zinb", BIC_ZINB);
  ENTRY("nal-zihp", NAL_ZIHP);
  ENTRY("pnal-zihp", PNAL_ZIHP);
  ENTRY("nal-zinb", NAL_ZINB);
  ENTRY("pnal-zinb", PNAL_ZINB);
  ENTRY("custom-score", CUSTOM);

  return ENOSCORE;

}/*SCORE_TO_ENUM*/

gprior_e gprior_to_enum(const char *label) {

  ENTRY("uniform", UNIFORM);
  ENTRY("vsp", VSP);
  ENTRY("cs", CS);
  ENTRY("marginal", MU);

  return ENOPRIOR;

}/*GPRIOR_TO_ENUM*/

