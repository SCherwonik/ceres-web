/* quantreglite: registers the one Fortran routine it carries (rqbr, from
   quantreg's src/rqbr.f), as quantreg's src/quantreg_init.c does for it. */
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

extern void F77_NAME(rqbr)(void *, void *, void *, void *, void *, void *, void *, void *, void *,
                           void *, void *, void *, void *, void *, void *, void *, void *, void *,
                           void *, void *, void *, void *, void *, void *, void *, void *, void *);

static const R_FortranMethodDef FortranEntries[] = {
    {"rqbr", (DL_FUNC) &F77_NAME(rqbr), 27},
    {NULL, NULL, 0}
};

void R_init_quantreglite(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, NULL, FortranEntries, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
