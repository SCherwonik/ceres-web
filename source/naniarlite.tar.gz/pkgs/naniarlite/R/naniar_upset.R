## from naniar R/gg-miss-upset.R
gg_miss_upset <- function(data, order.by = "freq", ...){

  data %>%
    as_shadow_upset() %>%
    UpSetR::upset(order.by = order.by,
                  ...)

}

## from naniar R/n-var-miss.R
n_var_miss <- function(data){
  sum(colSums(is.na(data)) != 0)
}

## from naniar R/shadows.R
as_shadow_upset <- function(data){

  if (n_var_miss(data) <= 1 ) {

    if (n_var_miss(data) == 1) {
      glu_st <- glue::glue("upset plots for missing data requre at least two \\
                         variables to have missing data, only one variable, \\
                         '{miss_var_which(data)}' has missing values.")
    }

    if (n_var_miss(data) == 0) {

      glu_st <- glue::glue("upset plots for missing data requre at least two \\
                         variables to have missing data, there are no missing \\
                         values in your data! This is probably a good thing.")
    }

    rlang::abort(message = glu_st)
  }

  test_if_null(data)

  test_if_dataframe(data)

  data_shadow <- as.data.frame(is.na(data)*1)

  names(data_shadow) <- paste0(names(data),"_NA")

  dplyr::mutate_if(data_shadow, is.numeric, as.integer)

}

## from naniar R/utils.R
test_if_null <- function(x,
                         call = rlang::caller_env()) {
  # test for null
  if (is.null(x)) {
    cli::cli_abort(
      message = c(
        "Input must not be NULL",
        "Input is {.cls {class(x)}}"
      ),
      call = call
    )
  }
}

## from naniar R/utils.R
test_if_dataframe <- function(x,
                              arg = rlang::caller_arg(x),
                              call = rlang::caller_env()) {
  # test for dataframe
  if (!inherits(x, "data.frame")) {
    cli::cli_abort(
      message = c(
        "Input must inherit from {.cls data.frame}",
        "We see class: {.cls {class(x)}}"
      ),
      call = call
    )
  }
}

