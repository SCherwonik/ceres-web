
#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
